# 📹 Web IP Webcam

A modern, browser-based IP camera system. One device streams its camera via WebRTC;
any other device on the same network (or across the internet) can watch live in real time.

## ⚡ Quick Start

### 1. Install dependencies

```bash
cd server
npm install