npm start
# Server runs at http://localhost:3000