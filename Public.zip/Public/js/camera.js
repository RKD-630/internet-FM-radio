// Camera/Broadcaster logic: capture local media, negotiate WebRTC with each viewer.
const SERVER = localStorage.getItem('serverUrl') || location.origin;
const socket = io(SERVER);

const $ = (id) => document.getElementById(id);
const video = $('localVideo');
const statusEl = $('status');
const btnStart = $('btnStart'), btnStop = $('btnStop'), btnSwitch = $('btnSwitch');
const btnFlash = $('btnFlash'), btnFs = $('btnFullscreen');
let localStream = null;
let sessionId = null;
let peers = new Map();         // viewerId -> RTCPeerConnection
let facingMode = 'environment';
let flashOn = false;
let track = null;
let startTime = 0;
let timerInterval = null;
let frameCount = 0, lastFpsTime = Date.now();

const iceServers = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' }
];

function setStatus(text, cls = 'red') {
  statusEl.innerHTML = `<span class="dot dot-${cls}"></span> ${text}`;
}

async function startCamera() {
  const res = parseInt($('resolution').value);
  const audio = $('audio').value === 'true';
  const constraints = {
    video: {
      facingMode: { ideal: facingMode },
      width:  { ideal: res === 1080 ? 1920 : res === 720 ? 1280 : 854 },
      height: { ideal: res === 1080 ? 1080 : res === 720 ? 720  : 480 }
    },
    audio
  };

  try {
    localStream = await navigator.mediaDevices.getUserMedia(constraints);
    video.srcObject = localStream;
    track = localStream.getVideoTracks()[0];
    $('resolution').disabled = true;
    $('audio').disabled = true;
    btnStart.disabled = true;
    btnStop.disabled = false;
    btnSwitch.disabled = false;
    btnFlash.disabled = !(track.getCapabilities?.().torch);
    setStatus('Streaming', 'green');

    const settings = track.getSettings();
    $('res').textContent = `${settings.width || '?'}x${settings.height || '?'}`;

    // Start stream timer
    startTime = Date.now();
    timerInterval = setInterval(updateTimer, 1000);

    // Register session on signaling server
    socket.emit('create-session', { pin: $('pin').value || null }, (res) => {
      if (!res?.ok) return alert('Failed to create session.');
      sessionId = res.sessionId;
      const url = `${location.origin}/view.html?session=${sessionId}`;
      $('sessionUrl').textContent = url;
      $('qrcode').innerHTML = '';
      new QRCode($('qrcode'), { text: url, width: 180, height: 180 });
      $('sessionCard').style.display = 'block';
    });

    // FPS counter via requestVideoFrameCallback (where supported)
    if ('requestVideoFrameCallback' in HTMLVideoElement.prototype) {
      const countFrame = () => { frameCount++; video.requestVideoFrameCallback(countFrame); };
      video.requestVideoFrameCallback(countFrame);
    }
    setInterval(() => {
      const now = Date.now();
      const elapsed = (now - lastFpsTime) / 1000;
      if (elapsed > 0) {
        const fps = Math.round(frameCount / elapsed);
        $('fps').textContent = isFinite(fps) ? fps : '—';
      }
      frameCount = 0; lastFpsTime = now;
    }, 2000);

  } catch (err) {
    console.error(err);
    alert('Camera access denied or unavailable: ' + err.message);
    setStatus('Error', 'red');
  }
}

function stopCamera() {
  if (localStream) localStream.getTracks().forEach(t => t.stop());
  localStream = null;
  peers.forEach(pc => pc.close());
  peers.clear();
  video.srcObject = null;
  sessionId = null;
  btnStart.disabled = false;
  btnStop.disabled = true;
  btnSwitch.disabled = true;
  btnFlash.disabled = true;
  $('sessionCard').style.display = 'none';
  $('resolution').disabled = false;
  $('audio').disabled = false;
  clearInterval(timerInterval);
  $('timer').textContent = '00:00';
  $('viewers').textContent = '0';
  setStatus('Idle', 'red');
  socket.emit('disconnect-session');
}

async function switchCamera() {
  facingMode = facingMode === 'environment' ? 'user' : 'environment';
  await stopCamera();
  await startCamera();
}

async function toggleFlash() {
  if (!track) return;
  try {
    flashOn = !flashOn;
    await track.applyConstraints({ advanced: [{ torch: flashOn }] });
    btnFlash.innerHTML = `<span class="material-symbols-rounded">${flashOn ? 'flash_off' : 'flash_on'}</span> Flash`;
  } catch (e) { alert('Flashlight not supported on this device.'); }
}

function updateTimer() {
  const s = Math.floor((Date.now() - startTime) / 1000);
  const mm = String(Math.floor(s / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  $('timer').textContent = `${mm}:${ss}`;
}

// ---- WebRTC signaling (broadcaster side) ----
function createPeer(viewerId) {
  const pc = new RTCPeerConnection({ iceServers });
  localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
  pc.onicecandidate = (e) => {
    if (e.candidate) socket.emit('signal', { to: viewerId, data: { candidate: e.candidate } });
  };
  peers.set(viewerId, pc);
  $('viewers').textContent = peers.size;
  return pc;
}

socket.on('viewer-joined', async ({ viewerId }) => {
  const pc = createPeer(viewerId);
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  socket.emit('signal', { to: viewerId, data: { offer } });
});

socket.on('viewer-left', ({ viewerId }) => {
  peers.get(viewerId)?.close();
  peers.delete(viewerId);
  $('viewers').textContent = peers.size;
});

socket.on('signal', async ({ from, data }) => {
  const pc = peers.get(from);
  if (!pc) return;
  if (data.answer) await pc.setRemoteDescription(data.answer);
  if (data.candidate) await pc.addIceCandidate(data.candidate);
});

// ---- Events ----
btnStart.addEventListener('click', startCamera);
btnStop.addEventListener('click', stopCamera);
btnSwitch.addEventListener('click', switchCamera);
btnFlash.addEventListener('click', toggleFlash);
btnFs.addEventListener('click', () => {
  const el = $('videoWrap');
  if (!document.fullscreenElement) el.requestFullscreen?.();
  else document.exitFullscreen?.();
});

// Battery API
if ('getBattery' in navigator) {
  navigator.getBattery().then(b => {
    const update = () => $('battery').textContent = `${Math.round(b.level * 100)}%${b.charging ? ' ⚡' : ''}`;
    update();
    b.addEventListener('levelchange', update);
    b.addEventListener('chargingchange', update);
  });
} else $('battery').textContent = 'N/A';

window.addEventListener('beforeunload', stopCamera);