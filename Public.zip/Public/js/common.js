// Shared helpers
console.log('🎥 Web IP Webcam loaded');