// Viewer logic: join session, receive WebRTC stream from broadcaster.
const SERVER = localStorage.getItem('serverUrl') || location.origin;
const socket = io(SERVER);

const $ = (id) => document.getElementById(id);
const video = $('remoteVideo');
const statusEl = $('status');
let peer = null, sessionId = null, muted = true;

const iceServers = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' }
];

function setStatus(text, cls = 'red') {
  statusEl.innerHTML = `<span class="dot dot-${cls}"></span> ${text}`;
}

// Auto-fill from querystring (QR scan lands here)
const params = new URLSearchParams(location.search);
if (params.get('session')) {
  $('sessionId').value = params.get('session').toUpperCase();
  if (params.get('pin')) $('pin').value = params.get('pin');
}

function connect() {
  const id = $('sessionId').value.trim().toUpperCase();
  if (!id) return alert('Enter a Session ID.');
  sessionId = id;
  setStatus('Connecting...', 'yellow');

  socket.emit('join-session', { sessionId: id, pin: $('pin').value || null }, (res) => {
    if (!res?.ok) {
      setStatus('Disconnected', 'red');
      return alert(res.error || 'Connection failed.');
    }
    $('connectCard').style.display = 'none';
    $('playerCard').style.display = 'block';
    $('sidDisp').textContent = id;
    setupPeer();
  });
}

function setupPeer() {
  peer = new RTCPeerConnection({ iceServers });
  peer.ontrack = (e) => {
    video.srcObject = e.streams[0];
    setStatus('Connected', 'green');
    startStats();
  };
  peer.onicecandidate = (e) => {
    if (e.candidate && sessionId) {
      // Send to the broadcaster (the only other peer in our session)
      socket.emit('signal', { to: 'broadcaster', data: { candidate: e.candidate } });
    }
  };
  peer.onconnectionstatechange = () => {
    if (['disconnected', 'failed', 'closed'].includes(peer.connectionState)) {
      setStatus('Reconnecting...', 'yellow');
      setTimeout(() => { if (peer?.connectionState !== 'connected') connect(); }, 3000);
    }
  };
}

socket.on('signal', async ({ from, data }) => {
  if (!peer) return;
  try {
    if (data.offer) {
      await peer.setRemoteDescription(data.offer);
      const answer = await peer.createAnswer();
      await peer.setLocalDescription(answer);
      socket.emit('signal', { to: from, data: { answer } });
    }
    if (data.candidate) await peer.addIceCandidate(data.candidate);
  } catch (e) { console.error(e); }
});

socket.on('session-ended', () => {
  alert('Camera ended the stream.');
  disconnect();
});

function disconnect() {
  peer?.close(); peer = null;
  video.srcObject = null;
  $('connectCard').style.display = 'block';
  $('playerCard').style.display = 'none';
  setStatus('Disconnected', 'red');
  socket.disconnect();
  socket.connect();
}

function startStats() {
  let frames = 0, lastT = Date.now();
  if ('requestVideoFrameCallback' in HTMLVideoElement.prototype) {
    const tick = () => { frames++; video.requestVideoFrameCallback(tick); };
    video.requestVideoFrameCallback(tick);
  }
  setInterval(async () => {
    const now = Date.now();
    const fps = Math.round((frames * 1000) / (now - lastT));
    $('fps').textContent = isFinite(fps) ? fps : '—';
    frames = 0; lastT = now;

    if (peer) {
      try {
        const stats = await peer.getStats();
        stats.forEach(r => {
          if (r.type === 'inbound-rtp' && r.kind === 'video') {
            const packetsLost = r.packetsLost || 0;
            const packetsRecv = r.packetsReceived || 1;
            const lossRate = packetsLost / (packetsLost + packetsRecv);
            const quality = lossRate < 0.01 ? 'Excellent' : lossRate < 0.05 ? 'Good' : lossRate < 0.15 ? 'Fair' : 'Poor';
            $('quality').textContent = quality;
            $('latency').textContent = (r.jitter * 1000).toFixed(0) + 'ms';
          }
        });
      } catch {}
    }
  }, 2000);
}

function screenshot() {
  if (!video.videoWidth) return;
  const c = document.createElement('canvas');
  c.width = video.videoWidth; c.height = video.videoHeight;
  c.getContext('2d').drawImage(video, 0, 0);
  const a = document.createElement('a');
  a.download = `snapshot-${Date.now()}.png`;
  a.href = c.toDataURL('image/png');
  a.click();
}

// Events
$('btnConnect').addEventListener('click', connect);
$('btnDisconnect').addEventListener('click', disconnect);
$('btnRefresh').addEventListener('click', () => { disconnect(); setTimeout(connect, 500); });
$('btnScreenshot').addEventListener('click', screenshot);
$('btnMute').addEventListener('click', () => {
  muted = !muted;
  video.muted = muted;
  $('btnMute').innerHTML = `<span class="material-symbols-rounded">${muted ? 'volume_off' : 'volume_up'}</span> ${muted ? 'Unmute' : 'Mute'}`;
});
$('btnFullscreen').addEventListener('click', () => {
  const el = $('videoWrap');
  if (!document.fullscreenElement) el.requestFullscreen?.();
  else document.exitFullscreen?.();
});
$('btnScan').addEventListener('click', async () => {
  // Basic QR scan via BarcodeDetector (Chromium)
  if ('BarcodeDetector' in window) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      const v = document.createElement('video');
      v.srcObject = stream; await v.play();
      const det = new BarcodeDetector({ formats: ['qr_code'] });
      const scan = async () => {
        const codes = await det.detect(v);
        if (codes.length) {
          try {
            const u = new URL(codes[0].rawValue);
            const sid = u.searchParams.get('session');
            if (sid) { $('sessionId').value = sid; stream.getTracks().forEach(t=>t.stop()); alert('QR detected: ' + sid); return; }
          } catch {}
        }
        requestAnimationFrame(scan);
      };
      scan();
    } catch (e) { alert('Scan not supported: ' + e.message); }
  } else {
    alert('QR scanning requires a Chromium-based browser.');
  }
});