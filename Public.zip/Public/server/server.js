const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

app.use(cors());
// Serve static files from the parent directory
app.use(express.static(path.join(__dirname, '..')));

// Session storage: sessionId -> { broadcasterId, pin, viewers: Set() }
const sessions = new Map();

io.on('connection', (socket) => {
  console.log(`Socket connected: ${socket.id}`);

  // Broadcaster creates a session
  socket.on('create-session', ({ pin }, callback) => {
    // End any existing session for this socket first
    for (const [sid, session] of sessions.entries()) {
      if (session.broadcasterId === socket.id) {
        sessions.delete(sid);
        io.to(sid).emit('session-ended');
      }
    }

    const sessionId = uuidv4().substring(0, 8).toUpperCase();
    sessions.set(sessionId, {
      broadcasterId: socket.id,
      pin,
      viewers: new Set()
    });
    
    socket.join(sessionId);
    if (callback) callback({ ok: true, sessionId });
  });

  // Viewer joins a session
  socket.on('join-session', ({ sessionId, pin }, callback) => {
    const session = sessions.get(sessionId);
    if (!session) {
      if (callback) callback({ ok: false, error: 'Session not found.' });
      return;
    }

    if (session.pin && session.pin !== pin) {
      if (callback) callback({ ok: false, error: 'Incorrect PIN.' });
      return;
    }

    session.viewers.add(socket.id);
    socket.join(sessionId);
    
    // Notify broadcaster
    io.to(session.broadcasterId).emit('viewer-joined', { viewerId: socket.id });
    
    if (callback) callback({ ok: true });
  });

  // Relay signals
  socket.on('signal', ({ to, data }) => {
    // If 'to' is 'broadcaster', find the session this viewer belongs to
    if (to === 'broadcaster') {
      for (const [sid, session] of sessions.entries()) {
        if (session.viewers.has(socket.id)) {
          io.to(session.broadcasterId).emit('signal', { from: socket.id, data });
          break;
        }
      }
    } else {
      // Sending to a specific viewer
      io.to(to).emit('signal', { from: socket.id, data });
    }
  });

  // Broadcaster disconnects session explicitly
  socket.on('disconnect-session', () => {
    for (const [sid, session] of sessions.entries()) {
      if (session.broadcasterId === socket.id) {
        io.to(sid).emit('session-ended');
        sessions.delete(sid);
      }
    }
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    console.log(`Socket disconnected: ${socket.id}`);
    
    for (const [sid, session] of sessions.entries()) {
      if (session.broadcasterId === socket.id) {
        // Broadcaster disconnected
        io.to(sid).emit('session-ended');
        sessions.delete(sid);
      } else if (session.viewers.has(socket.id)) {
        // Viewer disconnected
        session.viewers.delete(socket.id);
        io.to(session.broadcasterId).emit('viewer-left', { viewerId: socket.id });
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
