const CACHE = 'ip-webcam-v1';
const ASSETS = ['/', '/index.html', '/camera.html', '/view.html', '/css/styles.css', '/js/common.js', '/js/camera.js', '/js/viewer.js'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('fetch', (e) => {
  if (e.request.url.includes('socket.io')) return; // never cache sockets
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request).catch(() => caches.match('/index.html')))
  );
});